<?php

declare(strict_types=1);

namespace App;

require_once(__DIR__ . './src/utils/debug.php');
require_once(__DIR__ . './src/View.php');

$configuration = require_once(__DIR__ . './config/config.php');

const DEFAULT_ACTION = 'MainPage';

$action = $_GET['action'] ?? DEFAULT_ACTION;

$view = new View();

$view->render($action, $configuration);