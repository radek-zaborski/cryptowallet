<?php
return [

  'host' => 'localhost',
  'database' => 'crypto',
  'user' => 'radex',
  'password' => '49XmeulOcCgwRO2O'


];